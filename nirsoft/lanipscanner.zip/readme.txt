


LANIPScanner v1.05
Copyright (c) 2025 - 2026 Nir Sofer
Web site: https://www.nirsoft.net/utils/lan_ip_scanner.html



Description
===========

LANIPScanner is a simple tool for Windows that scans your network and
displays the list of all computers and devices that are currently
connected to your network. LANIPScanner uses multiple network protocols
to scan your network, including ICMP (ping), ARP, NBNS, SSDP, mDNS, DNS.
For every computer or device that is connected to your network, the
following information is displayed (Only if it's available): IP Address,
MAC Address, MAC Address Company, Device Name, Workgroup, Device String,
Protocols List, Ping Time, Ping TTL, Device Type, IPv6 Address, IPv6 Link
Local Address.
When a device responses to SSDP or mDNS protocol, you can also view the
raw data received from the device in the lower pane, by selecting the
device in the upper pane.



System Requirements
===================

This tool works on any version of Windows starting from Windows XP and up
to Windows 11. Both 32-bit and 64-bit systems are supported.



Versions History
================


* Version 1.05:
  o Added 'Copy Clicked Cell' option to the right-click context menu,
    which copies to the clipboard the text of cell that you right-clicked
    with the mouse.
  o When a randomized MAC address is detected, it's displayed in the
    'MAC Address Company' column.
  o Updated the internal MAC addresses database.

* Version 1.00 - First release.



LANIPScanner vs Wireless Network Watcher
========================================

The LANIPScanner tool may look very similar to the Wireless Network
Watcher tool, but there are a few differences between them:


* The LANIPScanner tool uses multiple protocols to detect devices on
  your network, while Wireless Network Watcher mainly uses the ARP
  protocol to detect devices.
* LANIPScanner can detect devices on another subnet (if they respond to
  ping requests). Wireless Network Watcher cannot do this because ARP
  protocol doesn't work with another subnet.
* Wireless Network Watcher uses the MAC address to uniquely identify
  devices on your network, and many features of this tool are based on
  the MAC address of the device. LANIPScanner may detect devices without
  knowing their MAC address, so the advanced features based on the MAC
  address are not available in the LANIPScanner tool.



Start Using LANIPScanner
========================

LANIPScanner doesn't require any installation process or additional DLL
files. In order to start using it, simply run the executable file -
LANIPScanner.exe
After running LANIPScanner, you can start to scan your network by
pressing F5 (or by choosing 'Start Scanning' from the File menu).
LANIPScanner automatcially detects your local area network and the scans
the correct IP addresses range. Optionally, you can open the 'Advanced
Options' window (F9) and choose the desired network adapter or IP
addresses range to scan instead of the automatic scan.

Be aware that when you run this tool in the first time, the firewall of
Windows operating system will display a warning and you need to allow
this tool to access your network.



Lower Pane
==========

When a device responses to SSDP or mDNS protocol, you can select the
device in the upper pane in order to view in the lower pane the raw
information received from the device. If you don't need this feature, you
can hide the lower pane from View Menu -> Show Lower Pane.



Advanced Options
================

The 'Advanced Options' window allows you to change the following scanning
options:
* Scan Mode: You can choose to scan the default network (This is the
  default option), scan the network of the selected adapter, or scan the
  selected IP addresses range.
* Scan Direction: You can choose to scan the IP addresses in forward
  direction, backwards direction or in random order.
* Scan Interval: Allows you to choose the interval between every
  scanned IP address. You can choose any interval between 1 millisecond
  (The fastest scanning speed) and 500 milliseconds (The slowest scanning
  speed).

You can open the 'Advanced Options' window from Options Menu -> Advanced
Options or simply by pressing the F9 key.



LANIPScanner Columns
====================


* IP Address: The IP address of the device.
* MAC Address: The MAC address of the device.
* MAC Address Company: The company that manufactured the device or the
  network adapter of the device, according to the MAC address.
* Name: The name of the device.
* Workgroup: The workgroup of the computer/device. Workgroup
  information is taken from NBNS protocol.
* Device String: Device string taken from SSDP or mDNS protocol. It may
  contain the name of the device or additional information about the
  device.
* Protocols: List of protocols used to detect this device.
* Ping Time: Ping time, in milliseconds.
* Ping TTL:
* Device Type:
* IPv6 Address: IPv6 Address of the device.
* IPv6 Link Local Address: Link-Local IPv6 address of the device.



Translating LANIPScanner to other languages
===========================================

In order to translate LANIPScanner to other language, follow the
instructions below:
1. Run LANIPScanner with /savelangfile parameter:
   LANIPScanner.exe /savelangfile
   A file named LANIPScanner_lng.ini will be created in the folder of
   LANIPScanner utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run LANIPScanner, and all
   translated strings will be loaded from the language file.
   If you want to run LANIPScanner without the translation, simply rename
   the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via CD-ROM, DVD, Internet, or in any other way,
as long as you don't charge anything for this and you don't sell it or
distribute it as a part of commercial product. If you distribute this
utility, you must include all files in the distribution package, without
any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to support@nirsoft.net
